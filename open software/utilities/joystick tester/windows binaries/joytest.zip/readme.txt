Joystick Test Utility, Developed for KADE 
by Degenatrons
http://kadevice.com    

A joystick test utility which will show joystick movement and button inputs on-screen
Currently the utility supports USB HID Joystick and PS3 joystick input and input from
joystick encoders such as the KADE encoder.

The joystick test utility  will stay on top of your other sessions and will continue 
to record joystick input when it is not in focus.

Visit http://kadevice.com and http://kadevice.com/forum/ for more information.

VERSION HISTORY:

v0.1.0.0 - 26/01/2013
  Initial release of the joystick test utility.
